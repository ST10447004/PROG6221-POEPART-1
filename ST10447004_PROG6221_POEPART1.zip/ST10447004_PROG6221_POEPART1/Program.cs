﻿using System;
using System.Media;
using System.IO;
using System.Threading;
using NAudio.Wave;  

class CyberChatbot
{
    static void Main()
    {
        // Play Voice Greeting
        PlayVoiceGreeting("seabelo.wav");

        // Display ASCII Art with Colors
        DisplayAsciiArt();

        // Welcome Message
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("\n[Welcome to CyberBot] Your cybersecurity awareness assistant!\n");
        Console.ResetColor();

        // Chatbot Loop
        while (true)
        {
            Console.Write("You: ");
            string userInput = Console.ReadLine()?.ToLower();

            if (userInput == "exit")
            {
                Console.WriteLine("\nGoodbye! Stay safe online.");
                break;
            }

            RespondToUser(userInput);
        }
    }

    // Function to play the voice greeting
    static void PlayVoiceGreeting(string filePath)
    {
        try
        {
            if (File.Exists(filePath))
            {
                using (SoundPlayer player = new SoundPlayer(filePath))
                {
                    player.Play();
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Error: Audio file not found.");
                Console.ResetColor();
            }
        }
        catch (Exception ex)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Error playing audio: " + ex.Message);
            Console.ResetColor();
        }
    }

    // Function to display ASCII art with colors
    static void DisplayAsciiArt()
    {
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine(@"
  ██████╗██╗   ██╗██████╗ ███████╗██████╗  ██████╗ ████████╗
 ██╔════╝██║   ██║██╔══██╗██╔════╝██╔══██╗██╔═══██╗╚══██╔══╝
 ██║     ██║   ██║██████╔╝█████╗  ██████╔╝██║   ██║   ██║   
 ██║     ██║   ██║██╔═══╝ ██╔══╝  ██╔═══╝ ██║   ██║   ██║   
 ╚██████╗╚██████╔╝██║     ███████╗██║     ╚██████╔╝   ██║   
  ╚═════╝ ╚═════╝ ╚═╝     ╚══════╝╚═╝      ╚═════╝    ╚═╝   
");
        Console.ResetColor();
    }

    // Function to respond to user input
    static void RespondToUser(string input)
    {
        switch (input)
        {
            case "how are you?":
                TypeResponse("I'm just a chatbot, but I'm always ready to help you stay safe online!");
                break;
            case "what's your purpose?":
                TypeResponse("My mission is to help you learn about cybersecurity and protect yourself online.");
                break;
            case "what can i ask you about?":
                TypeResponse("You can ask me about online threats, password safety, phishing scams, safe browsing, and two-factor authentication.");
                break;
            case "what is phishing?":
                TypeResponse("Phishing is a cyber attack where scammers trick you into revealing personal information.");
                break;
            case "how do i create a strong password?":
                TypeResponse("Use at least 12 characters with uppercase, lowercase, numbers, and symbols. Avoid common words and personal info.");
                break;
            case "should i use the same password everywhere?":
                TypeResponse("No! Using the same password for multiple accounts is risky. If one site is hacked, all your accounts could be compromised.");
                break;
            case "what is a password manager?":
                TypeResponse("A password manager securely stores and generates strong passwords so you don’t have to remember them all.");
                break;
            case "what is 2fa?":
                TypeResponse("Two-Factor Authentication (2FA) adds an extra security layer by requiring a second form of verification, such as a code sent to your phone.");
                break;
            case "how can i browse the internet safely?":
                TypeResponse("Use a secure browser, avoid suspicious links, and check for 'https://' before entering personal information.");
                break;
            case "how can i spot a phishing email?":
                TypeResponse("Look for poor grammar, urgent requests, and suspicious links. Always verify the sender’s email address!");
                break;
            case "what should i do if i receive a phishing email?":
                TypeResponse("Do not click any links or download attachments. Report it to your email provider and delete it.");
                break;
            case "are public wi-fi networks safe?":
                TypeResponse("Public Wi-Fi can be risky. Avoid logging into sensitive accounts and use a VPN for added security.");
                break;
            case "what is malware?":
                TypeResponse("Malware is malicious software designed to harm or exploit devices, networks, or users. It includes viruses, spyware, and ransomware.");
                break;
            case "how can i protect my personal information online?":
                TypeResponse("Use strong passwords, enable 2FA, avoid oversharing on social media, and be cautious of phishing scams.");
                break;
            default:
                TypeResponse("Sorry, I don't understand that. Try asking about phishing, password security, or safe browsing.");
                break;
        }
    }

    // Simulates typing effect
    static void TypeResponse(string message)
    {
        foreach (char c in message)
        {
            Console.Write(c);
            Thread.Sleep(30);
        }
        Console.WriteLine("\n");
    }
}
